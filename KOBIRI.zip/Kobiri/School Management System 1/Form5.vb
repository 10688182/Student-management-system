﻿Imports System.Data.OleDb

Public Class Form5
    Dim pro As String

    Dim command As String
    Dim myconnection As OleDbConnection = New OleDbConnection
    Dim strsql As String
    Dim dr As OleDbDataReader
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"
        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "insert into Hall ( StudID, HallName, RoomNo) Values('" & TextBox2.Text & "', '" & ComboBox1.Text & "',  '" & TextBox1.Text & "')"
        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        cmd.Parameters.Add(New OleDbParameter("StudID", CType(TextBox2.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("HallName", CType(ComboBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("RoomNo", CType(TextBox1.Text, String)))

        MsgBox("Hall details Registered")


        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            ComboBox1.ResetText()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Update Hall set [HallName] = '" & ComboBox1.Text & "', [RoomNo] = '" & TextBox1.Text & "' where [StudID] = '" & TextBox2.Text & "'"

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        MsgBox("Hall  Record update ")
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            ComboBox1.ResetText()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        myconnection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"
        myconnection.Open()


        strsql = "select * from Hall where(studID ='" & TextBox2.Text & "')"
        Dim cmd As New OleDbCommand(strsql, myconnection)
        dr = cmd.ExecuteReader
        dr.Read()

        TextBox2.Text = dr("StudID")
        ComboBox1.Text = dr("HallName")
        TextBox1.Text = dr("RoomNo")

        myconnection.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Delete * from Hall where [StuID] = '" & TextBox2.Text & "' "

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)

        MsgBox(" Hall Record deleted ")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            ComboBox1.ResetText()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form4.Show()
        Me.Hide()
    End Sub
End Class